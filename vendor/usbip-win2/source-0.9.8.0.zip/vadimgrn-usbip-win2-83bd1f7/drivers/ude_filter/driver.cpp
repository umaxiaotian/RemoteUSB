/*
 * Copyright (c) 2022-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 * 
 * @see https://github.com/desowin/usbpcap/tree/master/USBPcapDriver
 */

#include "driver.h"
#include "trace.h"
#include "driver.tmh"

#include "irp.h"
#include "pnp.h"
#include "int_dev_ctrl.h"

#include <libdrv\remove_lock.h>

namespace
{

using namespace usbip;

_Function_class_(DRIVER_UNLOAD)
_IRQL_requires_(PASSIVE_LEVEL)
_IRQL_requires_same_
PAGED void driver_unload(_In_ DRIVER_OBJECT *drvobj)
{
	PAGED_CODE();
	Trace(TRACE_LEVEL_INFORMATION, "%04x", ptr04x(drvobj));
	WPP_CLEANUP(drvobj);
}

_Function_class_(IO_COMPLETION_ROUTINE)
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
NTSTATUS irp_complete(
        _In_ DEVICE_OBJECT*, _In_ IRP *irp, _In_reads_opt_(_Inexpressible_("varies")) void *context)
{
        auto fltr = static_cast<filter_ext*>(context);
        libdrv::RemoveLockGuard{fltr->remove_lock, libdrv::adopt_lock, irp};

        if (irp->PendingReturned) {
                IoMarkIrpPending(irp);
        }

        return ContinueCompletion;
}

_Function_class_(DRIVER_DISPATCH)
_IRQL_requires_max_(DISPATCH_LEVEL)
_IRQL_requires_same_
auto dispatch_lower(_In_ DEVICE_OBJECT *devobj, _Inout_ IRP *irp)
{
	auto &fltr = *get_filter_ext(devobj);

	libdrv::RemoveLockGuard lck(fltr.remove_lock, irp);
	if (auto err = lck.acquired()) {
		Trace(TRACE_LEVEL_ERROR, "Acquire remove lock %!STATUS!", err);
		return CompleteRequest(irp, err);
	}

        lck.clear();

        IoCopyCurrentIrpStackLocationToNext(irp);
        IoSetCompletionRoutine(irp, irp_complete, &fltr, true, true, true);

        return IoCallDriver(fltr.target, irp);
}

} // namespace


/*
 * warning C28168: The function 'dispatch_lower' does not have a _Dispatch_type_ annotation 
 * matching dispatch table position 'IRP_MJ_CREATE'...
 */
_Function_class_(DRIVER_INITIALIZE)
_IRQL_requires_same_
_IRQL_requires_(PASSIVE_LEVEL)
CS_INIT EXTERN_C NTSTATUS DriverEntry(_In_ DRIVER_OBJECT *drvobj, _In_ UNICODE_STRING *RegistryPath)
{
	ExInitializeDriverRuntime(0); // @see ExAllocatePool2

	WPP_INIT_TRACING(drvobj, RegistryPath);
	Trace(TRACE_LEVEL_INFORMATION, "%04x, '%!USTR!'", ptr04x(drvobj), RegistryPath);

	drvobj->DriverUnload = driver_unload;
	drvobj->DriverExtension->AddDevice = add_device;

#pragma warning(push)
#pragma warning(disable:28168)
	for (int i = 0; i <= IRP_MJ_MAXIMUM_FUNCTION; ++i) {
		drvobj->MajorFunction[i] = dispatch_lower;
	}
#pragma warning(pop)

	drvobj->MajorFunction[IRP_MJ_PNP] = pnp;
	drvobj->MajorFunction[IRP_MJ_INTERNAL_DEVICE_CONTROL] = int_dev_ctrl;

	return STATUS_SUCCESS;
}
