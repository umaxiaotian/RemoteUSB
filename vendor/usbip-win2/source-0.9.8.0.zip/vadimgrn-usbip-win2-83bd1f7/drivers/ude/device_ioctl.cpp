/*
 * Copyright (c) 2022-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#include "device_ioctl.h"
#include "trace.h"
#include "device_ioctl.tmh"

#include "context.h"
#include "wsk_context.h"
#include "device.h"
#include "request_list.h"
#include "wsk_receive.h"
#include "proto.h"
#include "network.h"
#include "ioctl.h"

#include "filter_request.h"
#include <ude_filter/request.h>

#include <libdrv/irp.h>
#include <libdrv/pdu.h>
#include <libdrv/ch9.h>
#include <libdrv/ch11.h>
#include <libdrv/lists.h>
#include <libdrv/usbdsc.h>
#include <libdrv/wsk_cpp.h>
#include <libdrv/usb_util.h>
#include <libdrv/dbgcommon.h>
#include <libdrv/usbd_helper.h>

#include <ntstrsafe.h>

namespace
{

using namespace usbip;

/*
 * wsk_irp->Tail.Overlay.DriverContext[] are zeroed.
 *
 * The completion handler for WskReceive is executed by a high priority thread
 * and is usually called before this handler.
 * @see wsk_receive.cpp, ret_command 
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
NTSTATUS send_complete(_In_ DEVICE_OBJECT*, _In_ IRP *wsk_irp, _In_reads_opt_(_Inexpressible_("varies")) void *context)
{
        wsk_context_ptr ctx(static_cast<wsk_context*>(context), true);

        auto request = ctx->request; // can be WDF_NO_HANDLE
        auto &dev = *ctx->dev;
        auto seqnum = request ? ctx.seqnum(true) : seqnum_t{};

        auto &wsk = wsk_irp->IoStatus;
        auto wsk_status = wsk.Status;

        TraceWSK("req %04x -> wsk irp %04x, %!STATUS!, Information %Iu", 
                  ptr04x(request), ptr04x(wsk_irp), wsk_status, wsk.Information);

        /*
         * WskSend is finished. Drop the partial MDL before publishing send completion:
         * it describes pages owned by the upper URB and does not lock them itself.
         */
        ctx->mdl_hdr.next(nullptr);
        ctx->mdl_buf.reset();

        if (wsk_status == STATUS_FILE_FORCED_CLOSED && !get_flag(dev.unplugged)) {
                auto device = get_handle(&dev);
                TraceDbg("dev %04x, unplugging after %!STATUS!", ptr04x(device), wsk_status);
                device::async_detach_and_delete(device, true);
        }

        /*
         * Publishing send completion is the last operation: the completion DPC can
         * complete the request on another processor immediately after that.
         */
        if (!request) {
                // nothing to do
        } else if (NT_SUCCESS(wsk_status)) {
                ++dev.sent_requests;
                auto st = device::on_send_complete(dev, request, seqnum, wsk_status);
                if (NT_ERROR(st)) {
                        auto device = get_handle(&dev);
                        device::send_cmd_unlink_and_complete(device, request, st);
                }
        } else {
                NT_VERIFY(NT_SUCCESS(device::on_send_complete(dev, request, seqnum, wsk_status)));
        }

        return StopCompletion;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
auto prepare_wsk_buf(_Inout_ WSK_BUF &buf, _Inout_ wsk_context &ctx, _Inout_opt_ const URB *transfer_buffer)
{
        NT_ASSERT(!ctx.mdl_buf);

        if (transfer_buffer && is_transfer_dir_out(ctx.hdr)) { // TransferFlags can have wrong direction
                auto st = make_transfer_buffer_mdl(ctx.mdl_buf, URB_BUF_LEN, IoReadAccess, *transfer_buffer);
                if (NT_ERROR(st)) {
                        Trace(TRACE_LEVEL_ERROR, "make_transfer_buffer_mdl %!STATUS!", st);
                        return st;
                }
        }

        ctx.mdl_hdr.next(ctx.mdl_buf); // always replace tie from previous call

        if (ctx.is_isoc) {
                NT_ASSERT(ctx.mdl_isoc);
                byteswap(ctx.isoc, number_of_packets(ctx));
                auto t = tail(ctx.mdl_hdr); // ctx.mdl_buf can be a chain
                t->Next = ctx.mdl_isoc.get();
        }

        buf.Mdl = ctx.mdl_hdr.get();
        buf.Offset = 0;
        buf.Length = get_total_size(ctx.hdr);

        NT_ASSERT(verify(buf, ctx.is_isoc));
        return STATUS_SUCCESS;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void send_pending(_Inout_ device_ctx &dev)
{
        if (InterlockedExchange(&dev.sending, true)) {
                return; // the other thread won the race
        }

        do {
                for (auto entry = libdrv::reverse(InterlockedFlushSList(&dev.pending_sends)); entry; ) {

                        auto &ctx = *CONTAINING_RECORD(entry, wsk_context, entry);
                        {
                                auto nxt = entry->Next;
                                entry->Next = nullptr;
                                entry = nxt;
                        }
                        auto req = ctx.request;
                        auto irp = ctx.wsk_irp.get();

                        auto buf = ctx.wsk_buf;
                        ctx.wsk_buf = WSK_BUF{};

                        auto st = send(dev.sock(), &buf, WSK_FLAG_NODELAY, irp);

                        TraceWSK("req %04x -> wsk irp %04x, %Iu bytes, %!STATUS!",
                                  ptr04x(req), ptr04x(irp), buf.Length, st);
                }

                InterlockedExchange(&dev.sending, false);

        } while (!(libdrv::empty(&dev.pending_sends) || InterlockedExchange(&dev.sending, true)));
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
auto send(_In_opt_ UDECXUSBENDPOINT endpoint, _Inout_ wsk_context_ptr &ctx, _Inout_ device_ctx &dev,
        _In_ bool log_setup, _Inout_opt_ const URB* transfer_buffer = nullptr)
{
        auto request = ctx->request; // can be WDF_NO_HANDLE, do not access after send
        auto &buf = ctx->wsk_buf;

        auto st = prepare_wsk_buf(buf, *ctx, transfer_buffer);

        if (NT_ERROR(st)) {
                return st;
        } else {
                char str[DBG_USBIP_HDR_BUFSZ];
                TraceEvents(TRACE_LEVEL_VERBOSE, FLAG_USBIP, "req %04x -> %Iu%s",
                        ptr04x(request), buf.Length, dbg_usbip_hdr(str, sizeof(str), &ctx->hdr, log_setup));
        }

        if (request && endpoint) {
                st = device::init_request_ctx(request, endpoint);
                if (NT_ERROR(st)) [[unlikely]] {
                        return st;
                }
                device::add_request_to_sent_list(dev, request, ctx->hdr.seqnum);
        }

        byteswap_header(ctx->hdr, swap_dir::host2net);
        IoSetCompletionRoutine(ctx->wsk_irp.get(), send_complete, ctx.get(), true, true, true);

        InterlockedPushEntrySList(&dev.pending_sends, &ctx.release()->entry);
        send_pending(dev);

        return STATUS_PENDING;
}

/*
 * @return device string descriptor index or zero if not a such kind of request
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
auto get_device_string_descr(_In_ const USB_DEFAULT_PIPE_SETUP_PACKET &s)
{
        return  s.bmRequestType.B == (USB_DIR_IN | USB_TYPE_STANDARD | USB_RECIP_DEVICE) &&
                s.bRequest == USB_REQUEST_GET_DESCRIPTOR &&
                s.wValue.HiByte == USB_STRING_DESCRIPTOR_TYPE ?
                s.wValue.LowByte : UCHAR(); // string index, zero for list of supported languages
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
auto fill_usb_device_serial(
        _In_ WDFREQUEST request, _Inout_ _URB_CONTROL_TRANSFER_EX &r,
        _In_ const vhci::imported_device_properties &props)
{
        constexpr UCHAR hdr_sz = libdrv::usb_string_descr_size(0);

        if (r.TransferBufferLength < hdr_sz) {
                Trace(TRACE_LEVEL_ERROR,"TransferBufferLength(%lu) < %d", r.TransferBufferLength, hdr_sz);
                return STATUS_BUFFER_TOO_SMALL;
        }

        size_t serial_cch;
        auto st = RtlStringCchLengthA(props.serial, ARRAYSIZE(props.serial), &serial_cch);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR,"RtlStringCchLengthA('%.15s') %!STATUS!", props.serial, st);
                return st;
        }

        USB_STRING_DESCRIPTOR *sd{};
        ULONG length; // can differ from r.TransferBufferLength, see prepare_wsk_mdl
        st = UdecxUrbRetrieveBuffer(request, reinterpret_cast<UCHAR**>(&sd), &length);
        if (NT_ERROR(st)) {
                Trace(TRACE_LEVEL_ERROR, "UdecxUrbRetrieveBuffer %!STATUS!", st);
                return st;
        }

        sd->bLength = libdrv::usb_string_descr_size(static_cast<UCHAR>(serial_cch));
        sd->bDescriptorType = USB_STRING_DESCRIPTOR_TYPE;

        auto buf_cch = (r.TransferBufferLength - hdr_sz)/sizeof(sd->bString);
        auto cch = min(buf_cch, serial_cch);

        for (size_t i{}; i < cch; ++i) {
                UCHAR ch = props.serial[i];
                NT_ASSERT(is_ascii(ch));
                sd->bString[i] = ch;
        }

        r.TransferBufferLength = libdrv::usb_string_descr_size(static_cast<UCHAR>(cch)); // UdecxUrbSetBytesCompleted
        return STATUS_SUCCESS;
}

using urb_function_t = NTSTATUS (device_ctx&, UDECXUSBENDPOINT, endpoint_ctx&, WDFREQUEST, URB&);

_IRQL_requires_max_(DISPATCH_LEVEL)
_Function_class_(urb_function_t)
auto control_transfer(
        _In_ device_ctx &dev, _In_ UDECXUSBENDPOINT endpoint, _In_ endpoint_ctx &endp,
        _In_ WDFREQUEST request, _In_ URB &urb)
{
        NT_ASSERT(usb_endpoint_type(endp.descriptor) == UsbdPipeTypeControl);

        static_assert(offsetof(_URB_CONTROL_TRANSFER, SetupPacket) == offsetof(_URB_CONTROL_TRANSFER_EX, SetupPacket));
        auto &r = urb.UrbControlTransferEx;

        if (r.PipeHandle && endp.PipeHandle != r.PipeHandle) { // r.PipeHandle is null if USBD_DEFAULT_PIPE_TRANSFER
                endp.PipeHandle = r.PipeHandle;
        }

        if (filter::is_request(r)) {
                auto func = filter::get_function(r, true);
                auto st = filter::unpack_request(dev, r, func);
                if (NT_ERROR(st)) {
                        return st;
                }
        }

        {
                char buf_flags[USBD_TRANSFER_FLAGS_BUFBZ];
                char buf_setup[USB_SETUP_PKT_STR_BUFBZ];

                TraceUrb("req %04x -> PipeHandle %04x, %s, TransferBufferLength %lu, Timeout %lu, %s",
                        ptr04x(request), ptr04x(r.PipeHandle),
                        usbd_transfer_flags(buf_flags, sizeof(buf_flags), r.TransferFlags),
                        r.TransferBufferLength,
                        urb.UrbHeader.Function == URB_FUNCTION_CONTROL_TRANSFER_EX ? r.Timeout : 0,
                        usb_setup_pkt_str(buf_setup, sizeof(buf_setup), r.SetupPacket));
        }

        auto buf_len = r.TransferBufferLength;
        auto &pkt = get_setup_packet(r); // @see UdecxUrbRetrieveControlSetupPacket

        if (buf_len > pkt.wLength) { // see drivers/usb/core/urb.c, usb_submit_urb
                buf_len = pkt.wLength; // usb_submit_urb checks for equality
        } else if (buf_len < pkt.wLength) {
                Trace(TRACE_LEVEL_ERROR, "TransferBufferLength(%lu) < wLength(%d)", buf_len, pkt.wLength);
                return STATUS_INVALID_PARAMETER;
        }

        if (auto idx = get_device_string_descr(pkt); !idx) {
                // not a string descriptor request or get list of supported languages
        } else if (auto &props = dev.ext().properties(); idx != props.iserial) {
                // not a iSerialNumber
        } else if (auto st = fill_usb_device_serial(request, r, props); NT_SUCCESS(st)) {
                return st;
        }

        wsk_context_ptr ctx(&dev, request);
        if (!ctx) {
                return STATUS_INSUFFICIENT_RESOURCES;
        }
        
        setup_dir dir_out = is_transfer_dir_out(urb.UrbControlTransfer); // default control pipe is bidirectional

        auto st = set_cmd_submit_usbip_header(ctx->hdr, dev, endp.descriptor, r.TransferFlags, buf_len, dir_out);
        if (NT_ERROR(st)) {
                return st;
        }

        static_assert(sizeof(ctx->hdr.cmd_submit.setup) == sizeof(pkt));
        RtlCopyMemory(ctx->hdr.cmd_submit.setup, &pkt, sizeof(pkt));

        return send(endpoint, ctx, dev, true, &urb);
}

_IRQL_requires_max_(DISPATCH_LEVEL)
_Function_class_(urb_function_t)
auto bulk_or_interrupt_transfer(
        _In_ device_ctx &dev, _In_ UDECXUSBENDPOINT endpoint, _In_ endpoint_ctx &endp,
        _In_ WDFREQUEST request, _In_ URB &urb)
{
        NT_ASSERT(usb_endpoint_type(endp.descriptor) == UsbdPipeTypeBulk || 
                  usb_endpoint_type(endp.descriptor) == UsbdPipeTypeInterrupt);

        auto &r = urb.UrbBulkOrInterruptTransfer;

        if (endp.PipeHandle != r.PipeHandle) {
                endp.PipeHandle = r.PipeHandle;
        }

        {
                auto func = urb.UrbHeader.Function == URB_FUNCTION_BULK_OR_INTERRUPT_TRANSFER_USING_CHAINED_MDL ? ", MDL" : " ";
                char buf[USBD_TRANSFER_FLAGS_BUFBZ];

                TraceUrb("req %04x -> PipeHandle %04x, %s, TransferBufferLength %lu%s",
                        ptr04x(request), ptr04x(r.PipeHandle), usbd_transfer_flags(buf, sizeof(buf), r.TransferFlags),
                        r.TransferBufferLength, func);
        }

        wsk_context_ptr ctx(&dev, request);
        if (!ctx) {
                return STATUS_INSUFFICIENT_RESOURCES;
        }

        auto st = set_cmd_submit_usbip_header(ctx->hdr, dev, endp.descriptor, r.TransferFlags, r.TransferBufferLength);
        if (NT_ERROR(st)) {
                return st;
        }

        return send(endpoint, ctx, dev, false, &urb);
}

/*
 * USBD_ISO_PACKET_DESCRIPTOR.Length is not used (zero) for USB_DIR_OUT transfer.
 */
_IRQL_requires_max_(DISPATCH_LEVEL)
auto repack(_In_ iso_packet_descriptor *d, _In_ const _URB_ISOCH_TRANSFER &r)
{
        ULONG length = 0;

        for (ULONG i = 0; i < r.NumberOfPackets; ++d) {

                auto offset = r.IsoPacket[i].Offset;
                auto next_offset = ++i < r.NumberOfPackets ? r.IsoPacket[i].Offset : r.TransferBufferLength;

                if (next_offset >= offset && next_offset <= r.TransferBufferLength) {
                        d->offset = offset;
                        d->length = next_offset - offset;
                        d->actual_length = 0;
                        d->status = 0;
                        length += d->length;
                } else {
                        Trace(TRACE_LEVEL_ERROR, "[%lu] next_offset(%lu) >= offset(%lu) && next_offset <= r.TransferBufferLength(%lu)",
                                i, next_offset, offset, r.TransferBufferLength);
                        return STATUS_INVALID_PARAMETER;
                }
        }

        NT_ASSERT(length == r.TransferBufferLength);
        return STATUS_SUCCESS;
}

/*
 * USBD_START_ISO_TRANSFER_ASAP is appended because URB_GET_CURRENT_FRAME_NUMBER is not implemented.
 */
_IRQL_requires_max_(DISPATCH_LEVEL)
_Function_class_(urb_function_t)
auto isoch_transfer(
        _In_ device_ctx &dev, _In_ UDECXUSBENDPOINT endpoint, _In_ endpoint_ctx &endp,
        _In_ WDFREQUEST request, _In_ URB &urb)
{
        NT_ASSERT(usb_endpoint_type(endp.descriptor) == UsbdPipeTypeIsochronous);
        auto &r = urb.UrbIsochronousTransfer;

        if (endp.PipeHandle != r.PipeHandle) {
                endp.PipeHandle = r.PipeHandle;
        }

        {
                const char *func = urb.UrbHeader.Function == URB_FUNCTION_ISOCH_TRANSFER_USING_CHAINED_MDL ? ", MDL" : " ";
                char buf[USBD_TRANSFER_FLAGS_BUFBZ];
                TraceUrb("req %04x -> PipeHandle %04x, %s, TransferBufferLength %lu, StartFrame %lu, NumberOfPackets %lu, ErrorCount %lu%s",
                        ptr04x(request), ptr04x(r.PipeHandle),
                        usbd_transfer_flags(buf, sizeof(buf), r.TransferFlags),
                        r.TransferBufferLength,
                        r.StartFrame,
                        r.NumberOfPackets,
                        r.ErrorCount,
                        func);
        }

        if (r.NumberOfPackets > max_iso_packets) {
                Trace(TRACE_LEVEL_ERROR, "NumberOfPackets(%lu) > USBIP_MAX_ISO_PACKETS(%d)", 
                                          r.NumberOfPackets, max_iso_packets);
                return STATUS_INVALID_PARAMETER;
        }

        wsk_context_ptr ctx(&dev, request, r.NumberOfPackets);
        if (!ctx) {
                return STATUS_INSUFFICIENT_RESOURCES;
        }

        auto st = set_cmd_submit_usbip_header(ctx->hdr, dev, endp.descriptor,
                        r.TransferFlags | USBD_START_ISO_TRANSFER_ASAP, r.TransferBufferLength);

        if (NT_ERROR(st)) {
                return st;
        }

        st = repack(ctx->isoc, r);
        if (NT_ERROR(st)) {
                return st;
        }

        if (auto cmd = &ctx->hdr.cmd_submit) {
                cmd->start_frame = r.StartFrame;
                cmd->number_of_packets = r.NumberOfPackets;
        }

        return send(endpoint, ctx, dev, false, &urb);
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
auto usb_submit_urb(
        _In_ device_ctx &dev, _In_ UDECXUSBENDPOINT endpoint, _In_ endpoint_ctx &endp, _In_ WDFREQUEST request)
{
        auto &urb = get_urb(request);
        urb_function_t *handler{};

        switch (auto func = urb.UrbHeader.Function) {
        case URB_FUNCTION_BULK_OR_INTERRUPT_TRANSFER:
        case URB_FUNCTION_BULK_OR_INTERRUPT_TRANSFER_USING_CHAINED_MDL:
                handler = bulk_or_interrupt_transfer;
                break;
        case URB_FUNCTION_ISOCH_TRANSFER:
        case URB_FUNCTION_ISOCH_TRANSFER_USING_CHAINED_MDL:
                handler = isoch_transfer;
                break;
        case URB_FUNCTION_CONTROL_TRANSFER_EX:
        case URB_FUNCTION_CONTROL_TRANSFER:
                handler = control_transfer;
                break;
        default:
                Trace(TRACE_LEVEL_ERROR, "%s(%#04x), dev %04x, endp %04x", urb_function_str(func), func, 
                                          ptr04x(endp.device), ptr04x(endpoint));

                return STATUS_NOT_SUPPORTED;
        }

        return handler(dev, endpoint, endp, request, urb);
}

/*
 * @param request can be WDF_NO_HANDLE
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
auto send_ep0_out(
        _In_ UDECXUSBDEVICE device, _In_opt_ WDFREQUEST request, _In_ const USB_DEFAULT_PIPE_SETUP_PACKET &setup)
{
        auto &dev = *get_device_ctx(device);

        wsk_context_ptr ctx(&dev, request);
        if (!ctx) {
                return STATUS_INSUFFICIENT_RESOURCES;
        }

        auto &ep0 = *get_endpoint_ctx(dev.ep0);
        const ULONG TransferFlags = USBD_DEFAULT_PIPE_TRANSFER | USBD_TRANSFER_DIRECTION_OUT;

        auto st = set_cmd_submit_usbip_header(ctx->hdr, dev, ep0.descriptor, TransferFlags, 0, setup_dir::out());
        if (NT_ERROR(st)) {
                return st;
        }

        if constexpr (auto &r = get_submit_setup(ctx->hdr); true) {
                r = setup;
                NT_ASSERT(!r.wLength);
                NT_ASSERT(is_transfer_dir_out(r));
        }

        return ::send(dev.ep0, ctx, dev, true);
}

} // namespace


 /*
  * There is a race condition between IRP cancelation and RET_SUBMIT.
  * Sequence of events:
  * 1.IRP is waiting for RET_SUBMIT in CSQ.
  * 2.An upper driver cancels IRP.
  * 3.IRP is removed from CSQ, IO_CSQ_COMPLETE_CANCELED_IRP callback is called.
  * 4.The callback inserts IRP into a list of unlinked IRPs (this step is imaginary).
  *
  * RET_SUBMIT can be received
  * a)Before #3 - normal case, IRP will be dequeued from CSQ.
  * b)Before #4 - IRP will not be found in CSQ and the list.
  * c)After #4 - IRP will be found in the list.
  *
  * Case b) is unavoidable because CSQ library calls IO_CSQ_COMPLETE_CANCELED_IRP after releasing a lock.
  * For that reason the cancellation logic is simplified and list of unlinked IRPs is not used.
  * RET_SUBMIT and RET_INLINK must be ignored if IRP is not found (IRP was cancelled and completed).
  */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void usbip::device::send_cmd_unlink_and_complete(_In_ UDECXUSBDEVICE device, _In_ WDFREQUEST request, _In_ NTSTATUS status)
{
        auto &dev = *get_device_ctx(device);
        auto &req = *get_request_ctx(request);

        TraceDbg("dev %04x, seqnum %u", ptr04x(device), req.seqnum);

        if (get_flag(dev.unplugged)) {
                TraceDbg("Unplugged, do not send unlink");
        } else if (auto ctx = wsk_context_ptr(&dev, WDFREQUEST(WDF_NO_HANDLE))) {
                set_cmd_unlink_usbip_header(ctx->hdr, dev, req.seqnum);
                ::send(WDF_NO_HANDLE, ctx, dev, false); // ignore error
        } else {
                Trace(TRACE_LEVEL_ERROR, "dev %04x, seqnum %u, wsk_context_ptr error", ptr04x(device), req.seqnum);
        }

        device::enqueue_for_completion(request, status);
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
USB_DEFAULT_PIPE_SETUP_PACKET usbip::device::make_set_configuration(_In_ UCHAR ConfigurationValue)
{
        return USB_DEFAULT_PIPE_SETUP_PACKET {
                .bmRequestType{.B = USB_DIR_OUT | USB_TYPE_STANDARD | USB_RECIP_DEVICE},
                .bRequest = USB_REQUEST_SET_CONFIGURATION,
                .wValue{.W = ConfigurationValue},
        };
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
USB_DEFAULT_PIPE_SETUP_PACKET usbip::device::make_set_interface(
        _In_ UCHAR InterfaceNumber, _In_ UCHAR AlternateSetting)
{
        return USB_DEFAULT_PIPE_SETUP_PACKET {
                .bmRequestType{.B = USB_DIR_OUT | USB_TYPE_STANDARD | USB_RECIP_INTERFACE},
                .bRequest = USB_REQUEST_SET_INTERFACE,
                .wValue{.W = AlternateSetting},
                .wIndex{.W = InterfaceNumber},
        };
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
USB_DEFAULT_PIPE_SETUP_PACKET usbip::device::make_clear_endpoint_stall(_In_ UCHAR EndpointAddress)
{
        return USB_DEFAULT_PIPE_SETUP_PACKET {
                .bmRequestType{.B = USB_DIR_OUT | USB_TYPE_STANDARD | USB_RECIP_ENDPOINT},
                .bRequest = USB_REQUEST_CLEAR_FEATURE,
                .wValue{.W = USB_FEATURE_ENDPOINT_STALL},
                .wIndex{.W = EndpointAddress},
        };
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
USB_DEFAULT_PIPE_SETUP_PACKET usbip::device::make_reset_port(_In_ USHORT port)
{
        static_assert(USB_RT_PORT == (USB_DIR_OUT | USB_TYPE_CLASS | USB_RECIP_OTHER));

        return USB_DEFAULT_PIPE_SETUP_PACKET {
                .bmRequestType{.B = USB_RT_PORT},
                .bRequest = USB_REQUEST_SET_FEATURE,
                .wValue{.W = USB_PORT_FEAT_RESET},
                .wIndex{.W = port},
        };
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
NTSTATUS usbip::device::set_configuration(
        _In_ UDECXUSBDEVICE device, _In_opt_ WDFREQUEST request, _In_ UCHAR ConfigurationValue)
{
        TraceDbg("dev %04x, ConfigurationValue %d", ptr04x(device), ConfigurationValue);

        auto r = make_set_configuration(ConfigurationValue);
        return send_ep0_out(device, request, r);
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
NTSTATUS usbip::device::set_interface(
        _In_ UDECXUSBDEVICE device, _In_opt_ WDFREQUEST request, 
        _In_ UCHAR InterfaceNumber, _In_ UCHAR AlternateSetting)
{
        TraceDbg("dev %04x, %d.%d", ptr04x(device), InterfaceNumber, AlternateSetting);

        auto r = make_set_interface(InterfaceNumber, AlternateSetting);
        return send_ep0_out(device, request, r);
}

/*
 * @see <linux>/drivers/usb/core/message.c, usb_clear_halt
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
NTSTATUS usbip::device::clear_endpoint_stall(_In_ UDECXUSBENDPOINT endpoint, _In_opt_ WDFREQUEST request)
{
        auto &endp = *get_endpoint_ctx(endpoint);
        auto addr = endp.descriptor.bEndpointAddress;

        TraceDbg("dev %04x, endp %04x, bEndpointAddress %#x", ptr04x(endp.device), ptr04x(endpoint), addr);
 
        auto r = make_clear_endpoint_stall(addr);
        return send_ep0_out(endp.device, request, r);
}

/*
 * Call usb_reset_device on Linux side - warn interface drivers and perform a USB port reset.
 * @see <linux>/drivers/usb/usbip/stub_rx.c, is_reset_device_cmd, tweak_reset_device_cmd
 * @see <linux>/drivers/usb/usbip/vhci_hcd.c, vhci_hub_control
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
NTSTATUS usbip::device::reset_port(_In_ UDECXUSBDEVICE device, _In_opt_ WDFREQUEST request)
{
        auto &dev = *get_device_ctx(device);

        NT_ASSERT(dev.port >= 1);
        auto port = static_cast<USHORT>(dev.port); // meaningless for a server which ignores it

        TraceDbg("dev %04x, port %d", ptr04x(device), port);

        auto r = make_reset_port(port);
        return send_ep0_out(device, request, r);
}

/*
 * IRP_MJ_INTERNAL_DEVICE_CONTROL 
 */
_Function_class_(EVT_WDF_IO_QUEUE_IO_INTERNAL_DEVICE_CONTROL)
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
void NTAPI usbip::device::internal_control(
        _In_ WDFQUEUE queue, 
        _In_ WDFREQUEST request,
        _In_ size_t /*OutputBufferLength*/,
        _In_ size_t /*InputBufferLength*/,
        _In_ ULONG IoControlCode)
{
        if (IoControlCode != IOCTL_INTERNAL_USB_SUBMIT_URB) {
                auto st = STATUS_INVALID_DEVICE_REQUEST;
                Trace(TRACE_LEVEL_ERROR, "%s(%#08lX) %!STATUS!", internal_device_control_name(IoControlCode), IoControlCode, st);
                WdfRequestComplete(request, st);
                return;
        }

        auto endpoint = get_endpoint(queue);

        auto st = init_request_ctx(request, endpoint);
        if (NT_ERROR(st)) {
                UdecxUrbCompleteWithNtStatus(request, st); // low-resource fallback, cannot use the DPC without request_ctx
                return;
        }

        auto &endp = *get_endpoint_ctx(endpoint);
        auto &dev = *get_device_ctx(endp.device);

        if (get_flag(dev.unplugged)) [[unlikely]] {
                get_urb(request).UrbHeader.Status = USBD_STATUS_DEVICE_GONE;
                device::enqueue_for_completion(request, STATUS_SUCCESS);
        } else if (st = usb_submit_urb(dev, endpoint, endp, request); st != STATUS_PENDING) {
                if (NT_ERROR(st)) {
                        TraceDbg("%!STATUS!", st);
                }
                device::enqueue_for_completion(request, st);
        }
}
