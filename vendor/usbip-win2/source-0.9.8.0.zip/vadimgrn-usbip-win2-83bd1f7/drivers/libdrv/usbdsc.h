/*
 * Copyright (c) 2022-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#pragma once

#include <ntddk.h>
#include <usb.h>

namespace libdrv
{

enum : UCHAR { MS_OS_STRING_DESC_INDEX = 0xEE };

struct USB_OS_STRING_DESCRIPTOR : USB_COMMON_DESCRIPTOR
{
	WCHAR Signature[7]; // MSFT100
	UCHAR MS_VendorCode;
	UCHAR Pad;
};
static_assert(sizeof(USB_OS_STRING_DESCRIPTOR) == 18);

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr auto usb_string_descr_size(_In_ UCHAR n)
{
        auto cb = __builtin_offsetof(USB_STRING_DESCRIPTOR, bString) + n*sizeof(*USB_STRING_DESCRIPTOR::bString);
        if (cb >= MAXIMUM_USB_STRING_LENGTH) [[unlikely]] {
                return UCHAR{};
        }
        return static_cast<UCHAR>(cb);
}

static_assert(usb_string_descr_size(0) == sizeof(USB_COMMON_DESCRIPTOR));
static_assert(usb_string_descr_size(126) + 1 == MAXIMUM_USB_STRING_LENGTH);

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr auto is_valid(_In_ const USB_COMMON_DESCRIPTOR &d)
{
	return d.bLength >= sizeof(d);
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr auto is_valid(_In_ const USB_DEVICE_DESCRIPTOR &d)
{
	return  d.bLength == sizeof(d) && 
		d.bDescriptorType == USB_DEVICE_DESCRIPTOR_TYPE;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr auto is_valid(_In_ const USB_CONFIGURATION_DESCRIPTOR &d)
{
	return  d.bLength == sizeof(d) &&
		d.bDescriptorType == USB_CONFIGURATION_DESCRIPTOR_TYPE &&
		d.wTotalLength > d.bLength;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr auto is_valid(_In_ const USB_INTERFACE_DESCRIPTOR &d)
{
	return  d.bLength == sizeof(d) &&
		d.bDescriptorType == USB_INTERFACE_DESCRIPTOR_TYPE;
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr auto is_valid(_In_ const USB_STRING_DESCRIPTOR &d)
{
        return  d.bLength >= sizeof(USB_COMMON_DESCRIPTOR) && 
                d.bDescriptorType == USB_STRING_DESCRIPTOR_TYPE && 
                !(d.bLength % 2); // crucial check for UTF-16 character sizing
}
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
bool is_valid(_In_ const USB_OS_STRING_DESCRIPTOR &d);

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
inline auto next(_In_ USB_COMMON_DESCRIPTOR *d)
{
	NT_ASSERT(d);
	void *next = reinterpret_cast<char*>(d) + d->bLength;
	return static_cast<USB_COMMON_DESCRIPTOR*>(next);
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
inline auto next(_In_ const USBD_INTERFACE_INFORMATION *d)
{
	NT_ASSERT(d);
	const void *next = reinterpret_cast<const char*>(d) + d->Length;
	return static_cast<const USBD_INTERFACE_INFORMATION*>(next);
}

/*
 * @param type of the usb descriptor - interface, endpoint, string
 * @param cur nullptr for the first iteration or result from the previous iteration
 * @return next found descriptor or nullptr
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
USB_COMMON_DESCRIPTOR *find_next(
	_In_ USB_CONFIGURATION_DESCRIPTOR *cfg, _In_ LONG type, _In_opt_ USB_COMMON_DESCRIPTOR *cur);

} // namespace libdrv
