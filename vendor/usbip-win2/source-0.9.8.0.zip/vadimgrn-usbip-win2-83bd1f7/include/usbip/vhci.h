/*
 * Copyright (c) 2021-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#pragma once

#include <cstddef>
#include <guiddef.h>

#ifdef _KERNEL_MODE
  #include <wdm.h>
  #include <minwindef.h>
#else
  #include <windows.h>
  #include <winioctl.h>
#endif

#include "ch9.h"
#include "consts.h"

/*
 * Strings encoding is UTF8. 
 */

namespace usbip
{

/**
 * Check that the string consists only of ASCII alphanumeric characters.
 * @param s null-ternimated ASCII string
 * @param maxlen max buffer size
 * @return < 0 if parameters/characters are invalid,
 *         otherwise the same as strnlen(s, maxlen)
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr SSIZE_T is_ascii_alnum(_In_opt_ const char *s, _In_ SSIZE_T maxlen);

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr auto is_ascii(_In_ unsigned char ch) { return ch < 0x7F; }

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr auto pack_attach_flags(_In_ bool once, _In_ bool wsk_events)
{
        return (static_cast<ULONG>(once) << 1) |
                static_cast<ULONG>(wsk_events);
}

_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr void unpack_attach_flags(_Inout_ bool &once, _Inout_ bool &wsk_events, _In_ ULONG flags)
{
        once = flags & 2;
        wsk_events = flags & 1;
}

} // namespace usbip


namespace usbip::vhci
{

DEFINE_GUID(GUID_DEVINTERFACE_USB_HOST_CONTROLLER,
        0xB4030C06, 0xDC5F, 0x4FCC, 0x87, 0xEB, 0xE5, 0x51, 0x5A, 0x09, 0x35, 0xC0);

struct base
{
        ULONG size; // IN, self size
};

struct imported_device_location
{
        int port; // OUT, >= 1 or zero if an error

        char busid[BUS_ID_SIZE];
        char service[32]; // NI_MAXSERV
        char host[1025];  // NI_MAXHOST in ws2def.h
};
static_assert(!offsetof(imported_device_location, port)); // must be the first member

struct imported_device_properties
{
        UINT32 devid;
//      static_assert(sizeof(devid) == sizeof(usbip_header_basic::devid));

        usb_device_speed speed;
        static_assert(sizeof(speed) == sizeof(int));

        UINT16 vendor;
        UINT16 product;

        char serial[SERIAL_BUFSZ];
        UCHAR iserial; // USB_DEVICE_DESCRIPTOR.iSerialNumber

        bool wsk_events;
};

struct imported_device : imported_device_location, imported_device_properties {};

enum class state { unplugged, connecting, connected, plugged, disconnected, unplugging };

/*
 * There can be multiple event sources for one device,
 * each of them emits events with a unique source_id.
 */
struct device_state : base, imported_device
{
        state state;
        ULONG source_id;
};

} // namespace usbip::vhci


namespace usbip::vhci::ioctl
{

enum class function { // 12 bit
        plugin_hardware = 0x800, // values of less than 0x800 are reserved for Microsoft
        plugout_hardware, 
        get_imported_devices,
        set_persistent,
        get_persistent,
        stop_attach_attempts,
        plugin_hardware_once,
        plugout_hardware_and_reattach,
};

constexpr auto make(function id)
{
        return CTL_CODE(FILE_DEVICE_UNKNOWN, static_cast<int>(id), METHOD_BUFFERED, FILE_READ_DATA | FILE_WRITE_DATA);
}

enum {
        PLUGIN_HARDWARE = make(function::plugin_hardware),
        PLUGOUT_HARDWARE = make(function::plugout_hardware),
        GET_IMPORTED_DEVICES = make(function::get_imported_devices),
        SET_PERSISTENT = make(function::set_persistent),
        GET_PERSISTENT = make(function::get_persistent),
        STOP_ATTACH_ATTEMPTS = make(function::stop_attach_attempts),
        PLUGIN_HARDWARE_ONCE = make(function::plugin_hardware_once),
        PLUGOUT_HARDWARE_AND_REATTACH = make(function::plugout_hardware_and_reattach), // for internal use only
};

struct plugin_hardware : base, imported_device_location
{
        char serial[SERIAL_BUFSZ];
        bool wsk_events;
};

struct stop_attach_attempts : base, imported_device_location
{
        int count; // OUT, number of canceled requests
};

enum { PORT_ALL_CLOSEONLY = -2, PORT_ALL };

struct plugout_hardware : base
{
        int port;
};

struct get_imported_devices : base
{
        imported_device devices[ANYSIZE_ARRAY];
};

/*
 * clang emits an error for offsetof() due to the inheritance.
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
inline auto get_imported_devices_size(_In_ ULONG n)
{
        const auto offset = reinterpret_cast<size_t>(&static_cast<get_imported_devices*>(nullptr)->devices);
        return offset + n*sizeof(*get_imported_devices::devices);
}

} // namespace usbip::vhci::ioctl


/*
 * UTF-8 is designed so that all ASCII characters (0–127)
 * are represented by a single byte with the high bit set to 0.
 */
_IRQL_requires_same_
_IRQL_requires_max_(DISPATCH_LEVEL)
constexpr SSIZE_T usbip::is_ascii_alnum(_In_opt_ const char *s, _In_ SSIZE_T maxlen)
{
        if (!(s && maxlen >= 0)) {
                return -1;
        }

        for (SSIZE_T i = 0; i < maxlen; ++i) {

                unsigned char c = s[i];
                if (!c) {
                        return i;
                }

                auto alnum = (c <= 'z' && c >= 'a') ||
                             (c <= 'Z' && c >= 'A') ||
                             (c <= '9' && c >= '0');

                if (!alnum) {
                        return -1;
                }
        }

        return maxlen;
}

static_assert(usbip::is_ascii_alnum(nullptr, 1) < 0);
static_assert(usbip::is_ascii_alnum("", -1) < 0);
static_assert(usbip::is_ascii_alnum("", 0) == 0);
static_assert(usbip::is_ascii_alnum("", 1) == 0);
static_assert(usbip::is_ascii_alnum("1", 2) == 1);
static_assert(usbip::is_ascii_alnum("1@", 3) < 0);
static_assert(usbip::is_ascii_alnum("1", 1) == 1);
static_assert(usbip::is_ascii_alnum("1\0W", 4) == 1);
