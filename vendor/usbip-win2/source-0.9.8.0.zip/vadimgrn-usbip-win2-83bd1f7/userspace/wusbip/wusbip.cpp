/*
 * Copyright (c) 2023-2026 Vadym Hrynchyshyn <vadimgrn@gmail.com>
 */

#include "wusbip.h"
#include "taskbaricon.h"
#include "resource.h"
#include "persist.h"
#include "wxutils.h"
#include "utils.h"
#include "font.h"
#include "log.h"
#include "app.h"

#include <libusbip/remote.h>
#include <libusbip/persistent.h>
#include <libusbip/src/file_ver.h>

#include <wx/event.h>
#include <wx/msgdlg.h>
#include <wx/aboutdlg.h>
#include <wx/busyinfo.h>
#include <wx/dataview.h>
#include <wx/config.h>
#include <wx/textdlg.h>
#include <wx/headerctrl.h>
#include <wx/clipbrd.h>
#include <wx/persist/dataview.h>

#include <format>
#include <set>

namespace
{

using namespace usbip;

const auto g_persistent_mark = L'\u2713'; // CHECK MARK, 2714 HEAVY CHECK MARK
auto &g_key_devices = L"/devices";
auto &g_key_url = L"url";

/*
 * Menu/View/Appearance, radio items
 */
inline auto get_appearance_itemid(_In_ int appearance) noexcept
{
        return wxID_FILE1 + appearance;
}

inline auto get_appearance_value(_In_ int itemid) noexcept
{
        wxASSERT(itemid >= wxID_FILE1);
        return itemid - wxID_FILE1;
}

/*
 * COL_PERSISTENT is not saved with these GUI flags.
 */
consteval auto get_saved_keys()
{
        using key_val = std::pair<const wchar_t* const, column_pos_t>;

        return std::to_array<key_val>({
                { L"busid", COL_BUSID },
                { L"devid", COL_DEVID },
                { L"speed", COL_SPEED },
                { L"vendor", COL_VENDOR },
                { L"product", COL_PRODUCT },
                { L"serial", COL_SERIAL },
                { L"receive_mode", COL_RECEIVE_MODE },
                { L"notes", COL_NOTES },
        });
}

consteval auto get_saved_flags()
{
        unsigned int flags{};

        for (auto [key, col]: get_saved_keys()) {
                flags |= mkflag(col);
        }

        return flags;
}

constexpr auto is_port_residual(_In_ state st)
{
        switch (st) {
        using enum state;
        case unplugged:  // port > 0 if previous state was unplugging
        case connecting: // port is zero
        case connected:  // ...
                return true;
        case disconnected: // port > 0 if previous state was plugged
        case plugged:      // port > 0
        case unplugging:   // ...
        default:
                return false;
        }
}

template<typename T>
requires std::three_way_comparable<T>
auto as_set(_In_ std::vector<T> v)
{
        return std::set<T>(std::make_move_iterator(v.begin()),
                           std::make_move_iterator(v.end()));
}

void log(_In_ const device_state &st)
{
        auto &d = st.device;
        auto &loc = d.location;

        auto s = std::format("{}:{}/{} {}, port {}, devid {:x}, speed {}, vid {:x}, pid {:x}, serial '{}', {}, source {:x}",
                              loc.hostname, loc.service, loc.busid, vhci::get_state_str(st.state), d.port, d.devid,
                              static_cast<int>(d.speed), d.vendor, d.product, d.serial,
                              to_string(d.recv_mode).utf8_string(), st.source_id);

        wxLogVerbose(wxString::FromUTF8(s));
}

void log(_In_ const wxTreeListCtrl &tree, _In_ wxTreeListItem dev, _In_ const wxString &prefix)
{
        auto server = tree.GetItemParent(dev);
        auto &url = tree.GetItemText(server);

        auto s = wxString::Format(
                        L"%s:%s/%s, port '%s', devid '%s', speed '%s', vendor '%s', product '%s', "
                        L"serial '%s', state '%s', auto '%s', mode '%s', notes '%s', source '%s'", 
                        prefix, url,
                        tree.GetItemText(dev, COL_BUSID),
                        tree.GetItemText(dev, COL_PORT),
                        tree.GetItemText(dev, COL_DEVID),
                        tree.GetItemText(dev, COL_SPEED),
                        tree.GetItemText(dev, COL_VENDOR), 
                        tree.GetItemText(dev, COL_PRODUCT), 
                        tree.GetItemText(dev, COL_SERIAL), 
                        tree.GetItemText(dev, COL_STATE), 
                        tree.GetItemText(dev, COL_PERSISTENT), 
                        tree.GetItemText(dev, COL_RECEIVE_MODE), 
                        tree.GetItemText(dev, COL_NOTES),
                        tree.GetItemText(dev, COL_SOURCE_ID));

        wxLogVerbose(s);
}

auto load_license()
{
        wxString s;

        auto hres = FindResource(nullptr, MAKEINTRESOURCE(IDR_LICENSE), RT_RCDATA);
        if (!hres) {
                auto err = GetLastError();
                return s = wxString::Format(_("FindResource error %lu\n%s"), err, wxSysErrorMsg(err));
        }

        auto hmem = LoadResource(nullptr, hres);
        if (!hmem) {
                auto err = GetLastError();
                return s = wxString::Format(_("LoadResource error %lu\n%s"), err, wxSysErrorMsg(err));
        }

        auto txt = LockResource(hmem);
        auto len = SizeofResource(nullptr, hres);

        return s = wxString::FromAscii(static_cast<const char*>(txt), len);
}

/*
 * COL_SERIAL, COL_RECEIVE_MODE are present in saved and persistent.
 */
enum columns : unsigned int {
        saved_read_only = 1,
        saved_notes = 2,
        saved_serial = 4,
        saved_recv_mode = 8,
        saved_read_write = saved_notes | saved_serial | saved_recv_mode,
        saved_all = saved_read_only | saved_read_write,

        pers_persistent = 16,
        pers_serial = 32,
        pers_recv_mode = 64,
        pers_all = pers_persistent | pers_serial | pers_recv_mode
};

constexpr auto get_saved_rw_pairs()
{
        return std::to_array<std::pair<columns, column_pos_t>>({
                { columns::saved_notes, COL_NOTES },
                { columns::saved_serial, COL_SERIAL },
                { columns::saved_recv_mode, COL_RECEIVE_MODE },
        });
}

constexpr auto get_saved_rw_flags()
{
        unsigned int flags{};

        for (auto [dummy, col]: get_saved_rw_pairs()) {
                flags |= mkflag(col);
        }

        return flags;
}

auto set_saved_read_only(_Inout_ device_columns &dc, _In_ const device_columns &saved)
{
        unsigned int flags{};
        constexpr auto rw_flags = get_saved_rw_flags();

        for (auto [dummy, col]: get_saved_keys()) {
                if (auto flag = mkflag(col); !(flag & rw_flags)) {
                        dc[col] = saved[col];
                        flags |= flag;
                }
        }

        return flags;
}

auto update_from_registry(
        _Inout_ device_columns &dc, _In_ unsigned int flags, _In_ unsigned int columns,
        _In_ const std::set<persistent_device> &persistent)
{
        if (persistent.empty()) {
                return flags;
        }

        wxASSERT(columns & columns::pers_all);
        static_assert(!(get_saved_flags() & mkflag(COL_PERSISTENT)));

        auto key = make_persistent_device(dc);

        if (auto pd = persistent.find(key); pd != persistent.end()) {

                if (columns & columns::pers_persistent) {
                        dc[COL_PERSISTENT] = g_persistent_mark;
                        wxASSERT(!(flags & mkflag(COL_PERSISTENT)));
                        flags |= mkflag(COL_PERSISTENT);
                }

                if (columns & columns::pers_serial) {
                        dc[COL_SERIAL] = wxString::FromUTF8(pd->serial);
                        flags |= mkflag(COL_SERIAL);
                }

                if (columns & columns::pers_recv_mode) {
                        dc[COL_RECEIVE_MODE] = to_string(pd->recv_mode);
                        wxASSERT(flags & mkflag(COL_RECEIVE_MODE));
                }
        }

        return flags;
}

auto update_from_registry(
        _Inout_ device_columns &dc, _In_ unsigned int flags, _In_ unsigned int columns,
        _In_ const std::set<device_columns> &saved, _In_ const std::set<persistent_device> &persistent)
{
        wxASSERT(columns & columns::saved_all);

        if (auto i = saved.find(dc); i != saved.end()) {

                if (columns & columns::saved_read_only) {
                        flags |= set_saved_read_only(dc, *i);
                }

                for (auto [col_bit, col] : get_saved_rw_pairs()) {
                        if (columns & col_bit) {
                                dc[col] = (*i)[col];
                                wxASSERT((col == COL_RECEIVE_MODE) == bool(flags & mkflag(col)));
                                flags |= mkflag(col);
                        }
                }
        }

        return update_from_registry(dc, flags, columns, persistent);
}

using predicate_f = std::function<bool(const wxTreeListCtrl&, wxTreeListItem)>;

auto is_server(_In_ const wxTreeListCtrl &tree, _In_ wxTreeListItem item) // predicate_f
{
        return tree.GetItemParent(item) == tree.GetRootItem();
}

/*
 * @see is_empty(_In_ const device_columns &dc)
 * @see is_empty(_In_ const imported_device &d)
 */
auto is_empty(_In_ const wxTreeListCtrl &tree, _In_ wxTreeListItem dev) // predicate_f
{
        auto &s = tree.GetItemText(dev, COL_DEVID); 
        return s.empty();
}

auto is_server_or_empty(_In_ const wxTreeListCtrl &tree, _In_ wxTreeListItem item) // predicate_f
{
        return is_server(tree, item) || is_empty(tree, item);
}

auto get_devices(
        _In_ const wxTreeListCtrl &tree, _In_ const predicate_f &except_for = is_server_or_empty)
{
        wxTreeListItems v;

        for (auto item = tree.GetFirstItem(); item.IsOk(); item = tree.GetNextItem(item)) {
                if (!except_for(tree, item)) {
                        v.push_back(item);
                }
        }

        return v;
}

auto get_selected_devices(
        _In_ const wxTreeListCtrl &tree, _In_ const predicate_f &except_for = is_server_or_empty)
{
        wxTreeListItems v;
        tree.GetSelections(v);

        auto pred = [except_for, &tree] (auto &item) { return except_for(tree, item); };
        std::erase_if(v, pred);

        return v;
}

auto make_persistent_device(
        _In_ const wxTreeListCtrl &tree, _In_ wxTreeListItem server, _In_ wxTreeListItem device)
{
        auto &url = tree.GetItemText(server);
        auto &busid = tree.GetItemText(device);

        return usbip::make_persistent_device(url, busid,
                        tree.GetItemText(device, COL_SERIAL),
                        tree.GetItemText(device, COL_RECEIVE_MODE));
}

auto get_persistent(_In_ const Handle &vhci = get_vhci())
{
        std::set<persistent_device> result;

        if (auto v = vhci::get_persistent(vhci.get())) {
                result = as_set(*v);
        } else {
                auto err = GetLastError();
                wxLogVerbose(_("Could not get persistent info\nError %lu\n%s"), err, GetLastErrorMsg(err));
        }

        return result;
}

auto get_saved()
{
        auto &cfg = *wxConfig::Get();

        auto path = cfg.GetPath();
        cfg.SetPath(g_key_devices);

        std::vector<device_columns> result;
        wxString name;
        long idx;

        for (auto ok = cfg.GetFirstGroup(name, idx); ok; cfg.SetPath(L".."), ok = cfg.GetNextGroup(name, idx)) {

                cfg.SetPath(name);

                device_columns dev;
                auto &url = get_url(dev);

                url = cfg.Read(g_key_url);
                if (url.empty()) {
                        continue;
                }

                for (auto [key, col] : get_saved_keys()) {
                        dev[col] = cfg.Read(key);
                }

                if (dev[COL_BUSID].empty()) {
                        continue;
                }

                validate_receive_mode(dev[COL_RECEIVE_MODE]);
                result.push_back(std::move(dev));
        }

        cfg.SetPath(path);
        return result;
}

auto to_string(_In_ const wxTreeListCtrl &tree, _In_ wxTreeListItem dev)
{
        wxASSERT(tree.GetColumnCount() > COL_LAST_VISIBLE);

        wxString s;
        for (unsigned int n = COL_LAST_VISIBLE, i = 0; i <= n; ++i) {
                if (i) {
                        s += L',';
                } else if (auto server = tree.GetItemParent(dev); server.IsOk()) {
                        s += tree.GetItemText(server);
                        s += L'/';
                } else {
                        wxFAIL_MSG("server.IsOk");
                }
                s += tree.GetItemText(dev, i);
        }
        return s;
}

auto get_servers(_In_ const std::vector<device_columns> &devices)
{
        std::set<wxString> servers;

        for (wxString hostname, service; auto &dc: devices) {
                if (auto url = get_url(dc); split_server_url(url, hostname, service)) {
                        servers.insert(std::move(hostname));
                }
        }

        return servers;
}

} // namespace


class DeviceStateEvent : public wxEvent
{
public:
        DeviceStateEvent(_In_ device_state st) : 
                wxEvent(0, EVT_DEVICE_STATE),
                m_state(std::move(st)) {}

        wxEvent *Clone() const override { return new DeviceStateEvent(*this); }

        auto& get() const noexcept { return m_state; }
        auto& get() noexcept { return m_state; }

private:
        device_state m_state;
};
wxDEFINE_EVENT(EVT_DEVICE_STATE, DeviceStateEvent);


MainFrame::MainFrame(_In_ Handle read, _In_ int appearance) : 
        Frame(nullptr),
        m_log(new LogWindow(this, 
                m_menu_log->FindItem(ID_TOGGLE_LOG_WINDOW),
                m_menu_view->FindItem(wxID_ZOOM_IN),
                m_menu_view->FindItem(wxID_ZOOM_OUT),
                m_menu_view->FindItem(wxID_ZOOM_100))),
        m_read(std::move(read))
{
        wxASSERT(m_read);
        check_view_appearance(appearance);
        
        init();
        restore_state();
        post_refresh();
}

MainFrame::~MainFrame()
{
        m_treeListCtrl->SetItemComparator(nullptr);
}

void MainFrame::check_view_appearance(_In_ int appearance)
{
        auto id = get_appearance_itemid(appearance);

        if (auto itm = m_view_appearance->FindItem(id); itm && itm->GetKind() == wxITEM_RADIO) {
                itm->Check();
        } else {
                wxLogError(_("View/Appearance: invalid appearance %d"), appearance);
        }
}

void MainFrame::init()
{
        m_log->SetVerbose(true); // produce messages for wxLOG_Info
        m_log->SetLogLevel(DEFAULT_LOGLEVEL);

        auto app_name = wxGetApp().GetAppDisplayName();
        SetTitle(app_name);

        SetIcon(wxIcon(L"USBip")); // see wxwidgets.rc
        
        if (auto cfg = wxConfig::Get()) {
                cfg->SetStyle(wxCONFIG_USE_LOCAL_FILE);
        }

        set_menu_columns_labels();
        m_comboBoxServer->SetMaxLength(NI_MAXHOST);

        auto port = get_tcp_port();
        m_spinCtrlPort->SetValue(wxString::FromAscii(port)); // NI_MAXSERV

        init_tree_list();

        Bind(wxEVT_TIMER, &MainFrame::on_status_bar_timer, this);
        Bind(EVT_DEVICE_STATE, &MainFrame::on_device_state, this);
}

/*
 * FIXME: set first column bold.
 * FIXME: wxTreeListCtrl::OnMouseWheel event does not work if it is set in wxFormBuilder
 * 
 * MEDIUM FOREST GREEN
 * FOREST GREEN
 * CADET BLUE
 * LIGHT STEEL BLUE
 * MEDIUM ORCHID
 */
void MainFrame::init_tree_list()
{
        auto &tree = *m_treeListCtrl;
        auto &dv = *tree.GetDataView();

        tree.SetImages(get_tree_images());
        tree.SetItemComparator(&m_tree_cmp);

        tree.GetView()->Bind(wxEVT_MOUSEWHEEL, wxMouseEventHandler(MainFrame::on_tree_mouse_wheel), this);

        if (auto hdr = dv.GenericGetHeader()) {
                hdr->Bind(wxEVT_MOUSEWHEEL, wxMouseEventHandler(MainFrame::on_tree_mouse_wheel), this);
                if (auto colour = wxTheColourDatabase->Find(L"MEDIUM FOREST GREEN"); colour.IsOk()) { // for Light and Dark
                        hdr->SetForegroundColour(colour);
                }
        }
}

wxWithImages::Images MainFrame::get_tree_images()
{
        auto dark = wxSystemSettings::GetAppearance().IsDark();

        auto stock_bmp = wxArtProvider::GetBitmap(wxASCII_STR(wxART_GO_HOME), wxASCII_STR(wxART_LIST));
        auto size = stock_bmp.GetSize();

        return wxWithImages::Images { 
                wxBitmapBundle::FromSVGResource(wxASCII_STR(dark ? "computer_svg_dark" : "computer_svg"), size),
                wxBitmapBundle::FromSVGResource(wxASCII_STR(dark ? "usb_svg_dark" : "usb_svg"), size)
        };

        static_assert(IMG_SERVER == 0);
        static_assert(IMG_DEVICE == 1);
}

void MainFrame::restore_state()
{
        wxPersistentRegisterAndRestore(this, L"MainFrame"); // @see persist.h
        wxPersistentRegisterAndRestore(m_treeListCtrl->GetDataView(), m_treeListCtrl->GetName());
}

void MainFrame::post_refresh()
{
        wxCommandEvent evt(wxEVT_COMMAND_MENU_SELECTED, wxID_REFRESH);
        wxASSERT(m_menu_devices->FindItem(wxID_REFRESH)); // command belongs to this menu
        wxPostEvent(m_menu_devices, evt);
}

void MainFrame::post_exit()
{
        wxCommandEvent evt(wxEVT_COMMAND_MENU_SELECTED, wxID_EXIT);
        wxPostEvent(m_menu_file, evt);
}

void MainFrame::on_close(wxCloseEvent &event)
{
        wxLogVerbose(wxString::FromAscii(__func__));
        wxASSERT(event.GetEventType() == wxEVT_CLOSE_WINDOW);

        if (m_close_to_tray && event.CanVeto()) {
                iconize_to_tray();
                event.Veto();
                return;
        }

        break_read_loop();
        m_read_thread.join();

        event.Skip();
}

void MainFrame::on_exit(wxCommandEvent&)
{
        Close(true);
}

void MainFrame::iconize_to_tray()
{
        auto &log = *m_log->GetFrame();

        if (!m_taskbar_icon) {
                m_taskbar_icon = std::make_unique<TaskBarIcon>();
        } else if (m_taskbar_icon->IsIconInstalled()) {
                wxASSERT(!IsShown());
                wxASSERT(!log.IsShown());
                return;
        }
        
        if (!m_taskbar_icon->SetIcon(GetIcon(), GetTitle())) {
                wxLogError(_("Could not set taskbar icon"));
        } else {
                log.Hide();
                Hide();
        }
}

void MainFrame::read_loop()
{
        auto on_exit = [] (auto frame)
        {
                std::lock_guard<std::mutex> lock(frame->m_read_close_mtx);
                frame->m_read.close();
        };

        std::unique_ptr<MainFrame, decltype(on_exit)> ptr(this, on_exit);

        while (auto state = vhci::read_device_state(m_read.get())) {
                auto evt = new DeviceStateEvent(std::move(*state));
                QueueEvent(evt); // see on_device_state()
        }

        if (auto err = GetLastError(); err != ERROR_OPERATION_ABORTED) { // see CancelSynchronousIo
                wxLogError(_("vhci::read_device_state error %lu\n%s"), err, GetLastErrorMsg(err));
        }
}

void MainFrame::break_read_loop()
{
        auto cancel_read = [this] // CancelSynchronousIo hangs if thread was terminated
        {
                std::lock_guard<std::mutex> lock(m_read_close_mtx);
                return !m_read || CancelSynchronousIo(m_read_thread.native_handle());
        };

        for (int i = 0; i < 300 && !cancel_read(); ++i, std::this_thread::sleep_for(std::chrono::milliseconds(100))) {
                if (auto err = GetLastError(); err != ERROR_NOT_FOUND) { // could not find a request to cancel
                        wxLogError(_("CancelSynchronousIo error %lu\n%s"), err, wxSysErrorMsg(err));
                        break; // wxLogSysError does not compile if wxNO_IMPLICIT_WXSTRING_ENCODING is set
                }
        }
}

/*
 * GUI thread!
 * vhci::open() is used instead of get_vhci() becase of GUI thread locking:
 * 1. vhci:attach() is started in the separate thread.
 * 2. state::connecting is issued by the driver and on_device_state() is called in GUI thread.
 * 3. vhci::get_persistent() is called with the same HANDLE as vhci:attach().
 * 4. get_persistent() will be blocked as well as GUI thread until attach() is completed.
 * 5.The blocking will not happen if use different handles.
 */
void MainFrame::on_device_state(_In_ DeviceStateEvent &event)
{
        auto &tree = *m_treeListCtrl;

        auto &st = event.get();
        log(st);

        if (m_taskbar_icon && m_taskbar_icon->IsIconInstalled()) {
                auto s = wxString::FromAscii(vhci::get_state_str(st.state)) + L' ' + make_device_url(st.device.location);
                m_taskbar_icon->show_balloon(s);
        }

        auto [dev, added] = find_or_add_device(st.device.location);

        if (added) {
                auto server = tree.GetItemParent(dev);
                auto &url = tree.GetItemText(server);
                auto &busid = tree.GetItemText(dev);
                wxLogVerbose(_("Added %s/%s"), url, busid);
        }

        if (st.state == state::disconnected && is_empty(tree, dev)) { // connection has failed/closed
                wxLogVerbose(_("Transient device removed"));
                remove_device(dev);
                return;
        }

        if (auto &cur_id = tree.GetItemText(dev, COL_SOURCE_ID); cur_id.empty() || st.state == state::plugged) {
                // update state and source_id
        } else if (auto id = to_wxstring(st.source_id); id != cur_id) {
                wxLogVerbose(_("Skip event from source %s != %s"), id, cur_id);
                return;
        }

        if (st.state == state::disconnected || st.state == state::unplugged) { // could be the last event for the source
                st.source_id = 0; // clear COL_SOURCE_ID
        }

        auto [dc, flags] = make_device_columns(st);
        wxASSERT(flags);

        if (auto &port = dc[COL_PORT]; !port.empty() && is_port_residual(st.state)) {
                port.clear();
                flags |= mkflag(COL_PORT);
        }

        if (added) { // COL_SERIAL, COL_RECEIVE_MODE are actual
                auto saved = as_set(get_saved());
                auto persistent = get_persistent(vhci::open());
                constexpr auto cols = columns::saved_read_only | columns::saved_notes | columns::pers_persistent;
                flags = update_from_registry(dc, flags, cols, saved, persistent);
        }

        if (!added) {
                log(tree, dev, _("Before"));
        }

        update_device(dev, dc, flags);
        log(tree, dev, _("After"));
}

void MainFrame::on_has_devices_update_ui(wxUpdateUIEvent &event)
{
        auto v = get_devices(*m_treeListCtrl);
        event.Enable(!v.empty());
}

void MainFrame::on_has_selected_devices_update_ui(wxUpdateUIEvent &event)
{
        auto v = get_selected_devices(*m_treeListCtrl);
        event.Enable(!v.empty());
}

void MainFrame::on_has_any_selected_devices_update_ui(wxUpdateUIEvent &event)
{
        auto v = get_selected_devices(*m_treeListCtrl, is_server); // OK if is_empty()
        event.Enable(!v.empty());
}

void MainFrame::on_copy_rows(wxCommandEvent&)
{
        wxString rows;

        for (auto &tree = *m_treeListCtrl;
             auto &dev: get_selected_devices(tree, is_server)) {
                rows += to_string(tree, dev) + L'\n';
        }

        wxLogVerbose(rows);

        if (wxClipboardLocker lck; !lck) {
                wxLogError(_("Could not lock the clipboard"));
        } else if (auto data = std::make_unique<wxTextDataObject>(rows); wxTheClipboard->SetData(data.get())) {
                data.release();
        } else {
                wxLogError(_("Could not pass data to the clipboard"));
        }
}

void MainFrame::on_select_all(wxCommandEvent&)
{
        m_treeListCtrl->SelectAll();
}

wxTreeListItem MainFrame::get_edit_device()
{
        auto &tree = *m_treeListCtrl;
        wxTreeListItem item;

        if (auto v = get_selected_devices(tree); v.size() == 1) {
                item = v.front();
        }

        return item;
}

void MainFrame::on_edit_device_update_ui(wxUpdateUIEvent &event)
{
        auto item = get_edit_device();
        event.Enable(item.IsOk());
}

void MainFrame::edit_column_dlg(
        _In_ const wxString &title, _In_ column_pos_t col, _In_ int maxlen,
        _In_ const std::function<wxString (const wxString&)> &validator)
{
        auto dev = get_edit_device();
        if (!dev.IsOk()) {
                return;
        }

        auto &tree = *m_treeListCtrl;
        auto server = tree.GetItemParent(dev);

        auto &url = tree.GetItemText(server);
        auto &busid = tree.GetItemText(dev);
        auto caption = wxString::Format(_("%s for %s/%s"), title, url, busid);

        auto &vendor = tree.GetItemText(dev, COL_VENDOR);
        auto &product = tree.GetItemText(dev, COL_PRODUCT);
        auto message = wxString::Format(L"%s\n%s", vendor, product);

        for (auto value = tree.GetItemText(dev, col); ;) {

                wxTextEntryDialog dlg(this, message, caption, value, wxTextEntryDialogStyle);
                dlg.SetMaxLength(maxlen);

                if (dlg.ShowModal() != wxID_OK) {
                        break;
                }

                value = dlg.GetValue();

                if (!validator) {
                        //
                } else if (auto err = validator(value); !err.empty()) {
                        wxMessageDialog(this, err, title, wxICON_ERROR).ShowModal();
                        continue;
                }

                tree.SetItemText(dev, col, value);
                break;
        }
}

void MainFrame::on_edit_notes(wxCommandEvent&)
{
        enum { MAXLEN = 256 };
        edit_column_dlg(_("Notes"), COL_NOTES, MAXLEN, nullptr);
}

void MainFrame::on_edit_serial(wxCommandEvent&)
{
        auto validator = [] (const wxString &serial)
        {
                wxString err;
                if (auto s = serial.utf8_string(); !validate_device_serial(s)) {
                        err = GetLastErrorMsg();
                }
                return err;
        };

        auto maxlen = get_device_serial_maxlen();
        edit_column_dlg(_("Serial Number"), COL_SERIAL, maxlen, validator);
}

void MainFrame::on_edit_gen_serial(wxCommandEvent&)
{
        if (auto dev = get_edit_device(); dev.IsOk()) {
                auto s = generate_device_serial();
                auto ws = wxString::FromAscii(s.data(), s.size());
                m_treeListCtrl->SetItemText(dev, COL_SERIAL, ws);
        }
}

bool MainFrame::is_checked(_In_ wxTreeListItem device, _In_ column_pos_t col)
{
        auto &tree = *m_treeListCtrl;
   
        wxASSERT(tree.GetItemParent(device).IsOk()); // server
        wxASSERT(!tree.GetFirstChild(device).IsOk());

        auto &s = tree.GetItemText(device, col);
        return !s.empty();
}

void MainFrame::set_checked(_In_ wxTreeListItem device, _In_ column_pos_t col, _In_ bool checked)
{
        auto &tree = *m_treeListCtrl;

        wxASSERT(tree.GetItemParent(device).IsOk()); // server
        wxASSERT(!tree.GetFirstChild(device).IsOk());

        wxString val;
        if (checked) {
                val = g_persistent_mark; // CHECK MARK, 2714 HEAVY CHECK MARK
        }

        tree.SetItemText(device, col, val);
}

void MainFrame::on_log_show_update_ui(wxUpdateUIEvent &event)
{
        auto f = m_log->GetFrame();
        event.Check(f->IsShown());
}

void MainFrame::on_log_show(wxCommandEvent &event)
{
        bool checked = event.GetInt();
        m_log->Show(checked);
}

void MainFrame::on_view_zebra_update_ui(wxUpdateUIEvent &event)
{
        auto &dv = *m_treeListCtrl->GetDataView();
        auto check = dv.HasFlag(wxDV_ROW_LINES);
        event.Check(check);
}

void MainFrame::on_view_zebra(wxCommandEvent&)
{
        auto &dv = *m_treeListCtrl->GetDataView();
        dv.ToggleWindowStyle(wxDV_ROW_LINES);
        dv.Refresh(false);
}

void MainFrame::on_log_verbose_update_ui(wxUpdateUIEvent &event)
{
        auto verbose = m_log->GetLogLevel() == VERBOSE_LOGLEVEL;
        event.Check(verbose);
}

void MainFrame::on_log_verbose(wxCommandEvent &event)
{
        bool checked = event.GetInt();
        m_log->SetLogLevel(checked ? VERBOSE_LOGLEVEL : DEFAULT_LOGLEVEL);
}

void MainFrame::on_log_library_update_ui(wxUpdateUIEvent &event)
{
        auto verbose = m_log->GetLogLevel() == VERBOSE_LOGLEVEL;

        if (!verbose && is_library_log_enabled()) {
                enable_library_log(false);
        }

        event.Check(is_library_log_enabled());
        event.Enable(verbose);
}

void MainFrame::on_log_library(wxCommandEvent &event)
{
        bool checked = event.GetInt();
        enable_library_log(checked);
}

void MainFrame::on_start_in_tray_update_ui(wxUpdateUIEvent &event)
{
        event.Check(m_start_in_tray);
}

void MainFrame::on_start_in_tray(wxCommandEvent &event)
{
        bool checked = event.GetInt();
        m_start_in_tray = checked;
}

void MainFrame::on_close_to_tray_update_ui(wxUpdateUIEvent &event)
{
        event.Check(m_close_to_tray);
}

void MainFrame::on_close_to_tray(wxCommandEvent &event)
{
        bool checked = event.GetInt();
        m_close_to_tray = checked;
}

DWORD MainFrame::attach(
        _In_ const wxString &url, _In_ const wxString &busid,
        _In_ const wxString &serial, _In_ const wxString &recv_mode, _In_ bool once)
{
        wxString hostname;
        wxString service;

        if (!split_server_url(url, hostname, service)) {
                return ERROR_INVALID_PARAMETER;
        }

        vhci::attach_args args {
                .location {
                        .hostname = hostname.utf8_string(),
                        .service = service.utf8_string(),
                        .busid = busid.utf8_string(),
                },
                .serial = serial.utf8_string(),
                .recv_mode = to_receive_mode(recv_mode),
                .once = once
        };

        DWORD err{};
        auto f = [&err, args = std::move(args), vhci = get_vhci().get()]
        { 
                auto port = vhci::attach(vhci, args); 
                err = port > 0 ? ERROR_SUCCESS : GetLastError();
        };

        auto msg = wxString::Format(L"%s/%s", url, busid);
        run_cancellable(this, msg, _("Attaching"), std::move(f));

        return err;
}

void MainFrame::on_attach_once(wxCommandEvent&)
{
        attach(true);
}

void MainFrame::attach(_In_ bool once)
{
        wxLogVerbose(L"%s, once %d", wxString::FromAscii(__func__), once);

        for (auto &tree = *m_treeListCtrl; auto &dev: get_selected_devices(tree, is_server)) {

                auto server = tree.GetItemParent(dev);
                auto &url = tree.GetItemText(server);
                auto &busid = tree.GetItemText(dev);
                auto &serial = tree.GetItemText(dev, COL_SERIAL);
                auto &recv_mode = tree.GetItemText(dev, COL_RECEIVE_MODE);

                if (auto err = attach(url, busid, serial, recv_mode, once)) {
                        if (err != ERROR_OPERATION_ABORTED) {
                                wxLogError(_("Could not attach %s/%s\nError %lu\n%s"), 
                                              url, busid, err, GetLastErrorMsg(err));
                        }
                        break;
                }
        }
}

void MainFrame::on_attach_stop(wxCommandEvent&)
{
        auto &vhci = get_vhci();
        int total = 0;

        for (auto &tree = *m_treeListCtrl; auto &dev: get_selected_devices(tree, is_server)) {

                auto server = tree.GetItemParent(dev);
                auto pd = make_persistent_device(tree, server, dev);

                if (auto cnt = vhci::stop_attach_attempts(vhci.get(), &pd.location); cnt >= 0) {
                        total += cnt;
                        continue;
                }

                auto err = GetLastError();

                auto &url = tree.GetItemText(server);
                auto &busid = tree.GetItemText(dev);

                wxLogError(_("Could not stop attach attempts %s/%s\nError %lu\n%s"),
                              url, busid, err, GetLastErrorMsg(err));

                break;
        }

        set_status_text(wxString::Format(_("%d request(s) stopped"), total));
}

void MainFrame::on_attach_stop_all(wxCommandEvent&)
{
        auto &vhci = get_vhci();

        if (auto cnt = vhci::stop_attach_attempts(vhci.get(), nullptr); cnt < 0) {
                auto err = GetLastError();
                wxLogError(_("Could not stop attach attempts\nError %lu\n%s"), err, GetLastErrorMsg(err));
        } else {
                set_status_text(wxString::Format(_("%d request(s) stopped"), cnt));
        }
}

DWORD MainFrame::detach(_In_ int port)
{
        wxLogVerbose(_("Detach port %d"), port);
        auto err = ERROR_SUCCESS;

        auto f = [&err, port]
        {
                if (auto &vhci = get_vhci(); !vhci::detach(vhci.get(), port)) {
                        err = GetLastError();
                }
        };

        auto msg = wxString::Format(_("Port %d"), port);
        run_cancellable(this, msg, _("Detaching"), std::move(f));

        return err;
}

void MainFrame::on_detach(wxCommandEvent&)
{
        for (auto &tree = *m_treeListCtrl; auto &dev: get_selected_devices(tree)) {

                if (auto port = get_port(dev); !port) {
                        // 
                } else if (auto err = detach(port)) {
                        if (err != ERROR_OPERATION_ABORTED) {
                                wxLogError(_("Could not detach port %d\nError %lu\n%s"),
                                              port, err, GetLastErrorMsg(err));
                        }
                        break;
                }
        }
}

void MainFrame::on_detach_all(wxCommandEvent&) 
{
        if (auto err = detach(vhci::port_all); err && err != ERROR_OPERATION_ABORTED) {
                wxLogError(_("Could not detach all devices\nError %lu\n%s"),
                              err, GetLastErrorMsg(err));
        }
}

wxTreeListItem MainFrame::find_or_add_server(_In_ const wxString &url)
{
        auto &tree = *m_treeListCtrl;
        wxTreeListItem server;

        for (auto item = tree.GetFirstItem(); item.IsOk(); item = tree.GetNextSibling(item)) {
                if (tree.GetItemText(item) == url) {
                        wxASSERT(is_server(tree, item));
                        return server = item;
                }
        }

        return server = tree.AppendItem(tree.GetRootItem(), url, IMG_SERVER, IMG_SERVER);
}

std::pair<wxTreeListItem, bool> MainFrame::find_or_add_device(_In_ const wxString &url, _In_ const wxString &busid)
{
        std::pair<wxTreeListItem, bool> res;

        auto &tree = *m_treeListCtrl;
        auto server = find_or_add_server(url);

        for (auto item = tree.GetFirstChild(server); item.IsOk(); item = tree.GetNextSibling(item)) {
                if (tree.GetItemText(item) == busid) {
                        return res = std::make_pair(item, false);
                }
        }

        auto device = tree.AppendItem(server, busid, IMG_DEVICE, IMG_DEVICE);

        if (!tree.IsExpanded(server)) {
                tree.Expand(server);
        }

        return res = std::make_pair(device, true);
}

std::pair<wxTreeListItem, bool> MainFrame::find_or_add_device(_In_ const device_location &loc)
{
        auto url = make_server_url(loc);
        auto busid = wxString::FromUTF8(loc.busid);

        return find_or_add_device(url, busid);
}

std::pair<wxTreeListItem, bool> MainFrame::find_or_add_device(_In_ const device_columns &dc)
{
        auto &url = get_url(dc);
        return find_or_add_device(url, dc[COL_BUSID]);
}

void MainFrame::remove_device(_In_ wxTreeListItem device)
{
        wxASSERT(device.IsOk());
        auto &tree = *m_treeListCtrl;

        auto server = tree.GetItemParent(device);
        tree.DeleteItem(device);

        if (auto child = tree.GetFirstChild(server); !child.IsOk()) { // has no children
                tree.DeleteItem(server);
        }
}

void MainFrame::update_device(_In_ wxTreeListItem device, _In_ const device_columns &dc, _In_ unsigned int flags)
{
        auto &tree = *m_treeListCtrl;

        wxASSERT(device.IsOk());
        wxASSERT(tree.GetItemText(device) == dc[COL_BUSID]);
        wxASSERT(tree.GetItemText(tree.GetItemParent(device)) == get_url(dc));

        if (!flags) {
                return;
        }
        
        for (int i = UPD_COL_FIRST; i <= UPD_COL_LAST; ++i) {
                auto col = static_cast<column_pos_t>(i);

                if (auto &new_val = dc[col]; (flags & mkflag(col)) && new_val != tree.GetItemText(device, col)) {
                        tree.SetItemText(device, col, new_val);
                }
        }
}

void MainFrame::on_help_about(wxCommandEvent&)
{
        auto &v = win::get_file_version();
 
        wxAboutDialogInfo d;

        d.SetVersion(wx_string(v.GetProductVersion()));
        d.SetDescription(wx_string(v.GetFileDescription()));
        d.SetCopyright(wx_string(v.GetLegalCopyright()));

        d.AddDeveloper(L"Vadym Hrynchyshyn\t<vadimgrn@gmail.com>");
        d.SetWebSite(L"https://github.com/vadimgrn/usbip-win2", _("GitHub project page"));

        d.SetLicence(load_license());
        //d.SetIcon();

        wxAboutBox(d, this);
}

auto MainFrame::connect(
        _In_ const wxString &hostname, _In_ const wxString &service, 
        _In_ const std::string &hostname_u8, _In_ const std::string &service_u8)
{
        Socket sock;
        DWORD err{};

        auto f = [&sock, &err, host = hostname_u8.c_str(), svc = service_u8.c_str()]
        {
                sock = usbip::connect(host, svc, CANCEL_BY_APC);
                err = sock ? ERROR_SUCCESS : GetLastError();
        };

        auto msg = wxString::Format(L"%s:%s", hostname, service);
        run_cancellable(this, msg, _("Connecting"), std::move(f), cancel_connect);

        switch (err) {
        case ERROR_SUCCESS:
        case WSA_E_CANCELLED:
        case ERROR_CANCELLED:
                break;
        default:
                wxLogError(_("Could not connect to %s:%s\nError %lu\n%s"), hostname, service, err, GetLastErrorMsg(err));
        }

        return sock;
}

void MainFrame::add_exported_devices(wxCommandEvent&)
{
        auto &cb = *m_comboBoxServer;

        auto host = cb.GetValue();
        if (host.empty()) {
                cb.SetFocus();
                return;
        }

        auto port = wxString::Format(L"%d", m_spinCtrlPort->GetValue());
        wxLogVerbose(L"%s, host='%s', port='%s'", wxString::FromAscii(__func__), host, port);

        auto u8_host = host.utf8_string();
        auto u8_port = port.utf8_string();

        auto sock = connect(host, port, u8_host, u8_port);
        if (!sock) {
                return;
        }

        auto persistent = get_persistent();
        auto saved = as_set(get_saved());

        auto dev = [this, host = std::move(u8_host), port = std::move(u8_port), &persistent, &saved] (auto, auto &device)
        {
                device_state state {
                        .device = make_imported_device(std::move(host), std::move(port), device),
                };
                auto [dc, flags] = make_device_columns(state);

                wxASSERT(state.device.serial.empty());
                wxASSERT(!(flags & mkflag(COL_SERIAL)));

                wxASSERT(state.device.recv_mode == receive_mode::zero_copy);
                wxASSERT(flags & mkflag(COL_RECEIVE_MODE));
                wxASSERT(dc[COL_RECEIVE_MODE] == to_string(receive_mode::zero_copy));

                auto [item, added] = find_or_add_device(dc); 

                if (added) {
                        constexpr auto cols = columns::saved_read_write | columns::pers_all;
                        flags = update_from_registry(dc, flags, cols, saved, persistent);
                } else {
                        flags &= ~mkflags({COL_STATE, COL_RECEIVE_MODE}); // clear
                }

                update_device(item, dc, flags);
        };

        auto intf = [] <typename... Args> (Args&&...) {};

        if (!enum_exportable_devices(sock.get(), dev, intf)) {
                auto err = GetLastError();
                wxLogError(_("enum_exportable_devices error %lu\n%s"), err, GetLastErrorMsg(err));
        } else if (cb.FindString(host) != wxNOT_FOUND) {
                // already exists
        } else if (auto pos = cb.Append(host); cb.GetCount() > 32) {
                cb.Delete(pos > 0 ? --pos : ++pos);
        }
}

void MainFrame::set_menu_columns_labels()
{
        constexpr auto cnt = COL_LAST_VISIBLE + 1;

        auto &menu = *m_menu_columns;
        wxASSERT(menu.GetMenuItemCount() == cnt);

        auto &view = *m_treeListCtrl->GetDataView();
        wxASSERT(cnt < view.GetColumnCount());

        for (auto pos = 0; pos < cnt; ++pos) {
                auto col = view.GetColumn(pos);
                auto title = col->GetTitle();

                if (auto item = menu.FindItemByPosition(pos); item->GetItemLabel() != title) {
                        item->SetItemLabel(title);
                }
        }
}

wxDataViewColumn* MainFrame::find_column(_In_ const wxString &title) const noexcept
{
        auto &view = *m_treeListCtrl->GetDataView();

        for (auto n = view.GetColumnCount(), pos = 0U; pos < n; ++pos) {
                if (auto col = view.GetColumn(pos); col->GetTitle() == title) {
                        return col;
                }
        }

        wxLogDebug(_("%s: column '%s' not found"), wxString::FromAscii(__func__), title);
        return nullptr;
}

wxDataViewColumn* MainFrame::find_column(_In_ int item_id) const noexcept
{
        if (auto item = m_menu_columns->FindItem(item_id)) {
                auto title = item->GetItemLabel(); 
                return find_column(title);
        }

        wxLogDebug(_("%s: item id '%d' not found"), wxString::FromAscii(__func__), item_id);
        return nullptr;
}

void MainFrame::on_view_column_update_ui(wxUpdateUIEvent &event)
{
        if (auto id = event.GetId(); auto col = find_column(id)) {
                event.Check(col->IsShown());
        }
}

void MainFrame::on_view_column(wxCommandEvent &event)
{
        if (auto id = event.GetId(); auto col = find_column(id)) {
                bool checked = event.GetInt();
                col->SetHidden(!checked);
        }
}

void MainFrame::on_item_activated(wxTreeListEvent &event)
{
        auto &tree = *m_treeListCtrl;
        
        if (auto item = event.GetItem(); is_server(tree, item)) {
                //
        } else if (auto &state = tree.GetItemText(item, COL_STATE); state == to_string(state::unplugged)) {
                on_attach(event); 
        } else if (state == to_string(state::plugged)) {
                on_detach(event);
        }
}

void MainFrame::on_view_labels_update_ui(wxUpdateUIEvent &event)
{
        auto shown = m_auiToolBar->HasFlag(wxAUI_TB_TEXT);
        event.Check(shown);
}

void MainFrame::on_view_labels(wxCommandEvent &)
{
        auto &tb = *m_auiToolBar;
        tb.ToggleWindowStyle(wxAUI_TB_TEXT);
        tb.Refresh(false);
}

int MainFrame::get_port(_In_ wxTreeListItem dev) const
{
        auto &tree = *m_treeListCtrl;

        wxASSERT(!tree.GetFirstChild(dev).IsOk());
        auto &str = tree.GetItemText(dev, COL_PORT);

        int port;
        return str.ToInt(&port) ? port : 0;
}

void MainFrame::on_flip_auto(wxCommandEvent&)
{
        for (auto &dev: get_selected_devices(*m_treeListCtrl)) {
                auto ok = is_checked(dev, COL_PERSISTENT);
                set_checked(dev, COL_PERSISTENT, !ok);
        }
}

void MainFrame::on_flip_receive_mode(wxCommandEvent&)
{
        for (auto &tree = *m_treeListCtrl; auto &dev: get_selected_devices(tree)) {
                auto &mode = tree.GetItemText(dev, COL_RECEIVE_MODE);

                auto r = to_receive_mode(mode) == receive_mode::zero_copy ?
                                receive_mode::low_latency : receive_mode::zero_copy;

                auto &val = to_string(r);
                tree.SetItemText(dev, COL_RECEIVE_MODE, val);
        }
}

void MainFrame::save(_In_ const wxTreeListItems &devices)
{
        auto &cfg = *wxConfig::Get();
        auto path = cfg.GetPath();

        cfg.DeleteGroup(g_key_devices);
        cfg.SetPath(g_key_devices);

        std::vector<persistent_device> persistent;
        auto &tree = *m_treeListCtrl;

        for (int cnt = 0; auto &dev: devices) {

                cfg.SetPath(wxString::Format(L"%d", ++cnt));

                auto server = tree.GetItemParent(dev);
                auto &url = tree.GetItemText(server);

                cfg.Write(g_key_url, url);

                for (auto [key, col] : get_saved_keys()) {
                        auto &value = tree.GetItemText(dev, col);
                        cfg.Write(key, value);
                }

                if (is_checked(dev, COL_PERSISTENT)) {
                        persistent.emplace_back(make_persistent_device(tree, server, dev));
                }

                cfg.SetPath(L"..");
        }

        cfg.Flush();
        cfg.SetPath(path);

        set_status_text(wxString::Format(_("%zu device(s) saved"), devices.size()), std::chrono::seconds(30));

        if (auto &vhci = get_vhci(); !vhci::set_persistent(vhci.get(), persistent)) {
                auto err = GetLastError();
                wxLogError(_("Could not save persistent info\nError %lu\n%s"), err, GetLastErrorMsg(err));
        }
}

void MainFrame::on_save(wxCommandEvent&)
{
        auto devices = get_devices(*m_treeListCtrl);
        save(devices);
}

void MainFrame::on_save_selected(wxCommandEvent&)
{
        if (auto devices = get_selected_devices(*m_treeListCtrl); devices.empty()) {
                wxMessageBox(_("There are no selected devices"), _("Save selected"), wxICON_WARNING);
        } else {
                save(devices);
        }
}

void MainFrame::on_load(wxCommandEvent&)
{
        int cnt = 0;
        auto saved = get_saved();

        if (static bool once{}; !once) {
                once = true;
                for (auto &i: get_servers(saved)) {
                        m_comboBoxServer->Append(i);
                }
        }

        for (auto persistent = get_persistent(); auto &dc: saved) {

                auto flags = get_saved_flags();
                auto [dev, added] = find_or_add_device(dc);

                if (!(added || is_empty(*m_treeListCtrl, dev))) {
                        wxLogVerbose(_("Skip loading existing device %s/%s"), get_url(dc), dc[COL_BUSID]);
                        continue;
                }

                constexpr auto state_flag = mkflag(COL_STATE);
                static_assert(!(get_saved_flags() & state_flag));

                dc[COL_STATE] = to_string(state::unplugged);
                flags = update_from_registry(dc, flags | state_flag, columns::pers_all, persistent);

                update_device(dev, dc, flags);
                ++cnt;
        }

        set_status_text(wxString::Format(_("%d device(s) loaded"), cnt), std::chrono::seconds(30));
}

void MainFrame::on_reload(wxCommandEvent &event)
{
        wxLogVerbose(wxString::FromAscii(__func__));

        auto &tree = *m_treeListCtrl;
        tree.DeleteAllItems();

        auto &vhci = get_vhci();

        auto devices = vhci::get_imported_devices(vhci.get());
        if (!devices) {
                auto err = GetLastError();
                wxLogError(_("Could not get imported devices\nError %lu\n%s"), err, GetLastErrorMsg(err));
                return;
        }

        auto persistent = get_persistent(vhci);
        auto saved = as_set(get_saved());

        for (auto &dev: *devices) {
                auto [item, added] = find_or_add_device(dev.location);
                wxASSERT(added);
                
                device_state st {
                        .device = std::move(dev), 
                        .state = state::plugged 
                };

                auto [dc, flags] = make_device_columns(st); // COL_SERIAL, COL_RECEIVE_MODE are actual

                constexpr auto cols = columns::saved_notes | columns::pers_persistent;
                flags = update_from_registry(dc, flags, cols, saved, persistent);

                update_device(item, dc, flags);
        }

        if (static bool once; !once) {
                once = true;
                on_load(event);
        }
}

std::unique_ptr<wxMenu> MainFrame::create_menu(_In_ const menu_item_descr *items, _In_ int cnt)
{
        auto menu = std::make_unique<wxMenu>();

        for (int i = 0; i < cnt; ++i) {
                if (auto [id, src, handler] = items[i]; clone_menu_item(*menu, id, *src)) {
                        if (handler) {
                                menu->Bind(wxEVT_COMMAND_MENU_SELECTED, handler, this, id);
                        }
                }
        }

        return menu;
}

std::unique_ptr<wxMenu> MainFrame::create_tree_popup_menu()
{
        const menu_item_descr separator {wxID_SEPARATOR, nullptr, nullptr};

        const auto items = std::to_array<menu_item_descr>({
                { wxID_SELECTALL, m_menu_edit, &MainFrame::on_select_all },
                { wxID_COPY, m_menu_edit, &MainFrame::on_copy_rows },
                { wxID_SAVEAS, m_menu_file, &MainFrame::on_save_selected },
                separator,
                { ID_EDIT_NOTES, m_menu_edit, &MainFrame::on_edit_notes },
                { ID_FLIP_AUTO, m_menu_edit, &MainFrame::on_flip_auto },
                { ID_FLIP_RECEIVE_MODE, m_menu_edit, &MainFrame::on_flip_receive_mode },
                separator,
                { ID_EDIT_SERIAL, m_menu_edit, &MainFrame::on_edit_serial },
                { ID_EDIT_GEN_SERIAL, m_menu_edit, &MainFrame::on_edit_gen_serial },
        });

        return create_menu(items.data(), items.size());
}

void MainFrame::on_item_context_menu(wxTreeListEvent&)
{
        if (!m_tree_popup_menu) {
                m_tree_popup_menu = create_tree_popup_menu();
        }

        PopupMenu(m_tree_popup_menu.get());
}

/*
 * @see wxConfig::Get()->DeleteAll()
 */
void MainFrame::on_view_reset(wxCommandEvent&)
{
        wxMessageDialog dlg(this, _("Reset all settings and restart the app?"), _("Reset settings"),
                wxOK | wxCANCEL | wxCANCEL_DEFAULT | wxICON_WARNING | wxCENTRE);

        if (dlg.ShowModal() == wxID_CANCEL) {
                return;
        }

        wxPersistenceManager::Get().DisableSaving();	
        wxConfig::Get()->DeleteGroup(L"Persistent_Options"); // FIXME: private key, defined in src\msw\regconf.cpp

        wchar_t** argv = wxGetApp().argv;

        switch (wxExecute(argv)) {
        case 0: // the command could not be executed
        case -1: // can happen when using DDE under Windows for command execution
                wxLogError(_("Could not relaunch itself, please restart the app"));
                break;
        default:
                post_exit();
        }
}

void MainFrame::on_help_about_lib(wxCommandEvent&)
{
        wxInfoMessageBox(this);
}

void MainFrame::on_frame_mouse_wheel(wxMouseEvent &event)
{
        on_tree_mouse_wheel(event);
}

void MainFrame::on_tree_mouse_wheel(_In_ wxMouseEvent &event)
{
        if (event.GetModifiers() == wxMOD_CONTROL) { // only Ctrl is depressed
                auto dir = event.GetWheelRotation();
                change_font_size(m_treeListCtrl, dir);
        }
}

void MainFrame::on_view_font_increase(wxCommandEvent&)
{
        change_font_size(m_treeListCtrl, 1);
}

void MainFrame::on_view_font_decrease(wxCommandEvent&)
{
        change_font_size(m_treeListCtrl, -1);
}

void MainFrame::on_view_font_default(wxCommandEvent&)
{
        change_font_size(m_treeListCtrl, 0);
}

void MainFrame::on_view_appearance(wxCommandEvent &event)
{
        auto val = get_appearance_value(event.GetId());
        wxGetApp().write_appearance(val);

        wxLogStatus(_("Restart the app to change the appearance"));
}

void MainFrame::set_status_text(
        _In_ const wxString &text, _In_ std::chrono::seconds duration, _In_ bool verbose_log)
{
        if (verbose_log) {
                wxLogVerbose(text);
        }

        if (auto ms = duration_cast<std::chrono::milliseconds>(duration).count(); m_status_bar_timer.StartOnce(ms)) {
                m_statusBar->PushStatusText(text);
                ++m_status_text_pushes;
        } else {
                wxLogDebug(_("Could not start status bar timer"));
        }
}

void MainFrame::on_status_bar_timer(wxTimerEvent&)
{
        for (int i = 0; i < m_status_text_pushes; ++i) {
                m_statusBar->PopStatusText();
        }

        m_status_text_pushes = 0;
}
