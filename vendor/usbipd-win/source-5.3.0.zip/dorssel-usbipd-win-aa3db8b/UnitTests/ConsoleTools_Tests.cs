﻿// SPDX-FileCopyrightText: 2023 Frans van Dorsselaer
//
// SPDX-License-Identifier: GPL-3.0-only

using Usbipd.Automation;

namespace UnitTests;

[TestClass]
sealed class ConsoleTools_Tests
{
    [TestMethod]
#pragma warning disable CA1861 // Avoid constant arrays as arguments
    [DataRow("", 10, new[] { "" })]
    [DataRow("1", 10, new[] { "1" })]
    [DataRow("123456789", 10, new[] { "123456789" })]
    [DataRow("123456789a", 10, new[] { "123456789a " })]
    [DataRow("123456789ab", 10, new[] { "123456789ab" })]
    [DataRow("12345 789", 10, new[] { "12345 789" })]
    [DataRow("12345 789a", 10, new[] { "12345", "789a" })]
#pragma warning restore CA1861 // Avoid constant arrays as arguments
    public void Wrap(string input, int width, string[] expected)
    {
        var result = ConsoleTools.Wrap(input, width);
        CollectionAssert.AreEquivalent(expected, new List<string>(result));
    }


    [TestMethod]
    public void ReportError()
    {
        var console = new TestConsole();
        ConsoleTools.ReportError(console, "test");
        Assert.IsTrue(string.IsNullOrEmpty(console.OutText));
        Assert.IsFalse(string.IsNullOrEmpty(console.ErrorText));
    }

    [TestMethod]
    public void ReportWarning()
    {
        var console = new TestConsole();
        ConsoleTools.ReportWarning(console, "test");
        Assert.IsTrue(string.IsNullOrEmpty(console.OutText));
        Assert.IsFalse(string.IsNullOrEmpty(console.ErrorText));
    }

    [TestMethod]
    public void ReportInfo()
    {
        var console = new TestConsole();
        ConsoleTools.ReportInfo(console, "test");
        Assert.IsTrue(string.IsNullOrEmpty(console.OutText));
        Assert.IsFalse(string.IsNullOrEmpty(console.ErrorText));
    }

    [TestMethod]
    public void ReportRebootRequired()
    {
        var console = new TestConsole();
        ConsoleTools.ReportRebootRequired(console);
        Assert.IsTrue(string.IsNullOrEmpty(console.OutText));
        Assert.IsFalse(string.IsNullOrEmpty(console.ErrorText));
    }

    [TestMethod]
    [DataRow("VID_80EE&PID_CAFE", false)]
    [DataRow("Vid_80EE&Pid_Cafe", false)]
    [DataRow("VID_12AB&PID_34CD", true)]

    public void CheckNoStub(string hardwareId, bool noStub)
    {
        Assert.IsTrue(VidPid.TryParseId(hardwareId, out var vidPid), "Test data is invalid");
        var console = new TestConsole();
        if (noStub)
        {
            Assert.IsTrue(ConsoleTools.CheckNoStub(vidPid, console));
            Assert.IsTrue(string.IsNullOrEmpty(console.OutText));
            Assert.IsTrue(string.IsNullOrEmpty(console.ErrorText));
        }
        else
        {
            Assert.IsFalse(ConsoleTools.CheckNoStub(vidPid, console));
            Assert.IsTrue(string.IsNullOrEmpty(console.OutText));
            Assert.IsFalse(string.IsNullOrEmpty(console.ErrorText));
        }
    }
}
